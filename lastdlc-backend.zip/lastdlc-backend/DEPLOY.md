# 🚀 lastDLC — Инструкция по деплою

## Что у тебя теперь есть

```
lastdlc-backend/
├── server.js              ← Node.js бэкенд (API)
├── package.json           ← зависимости
├── .env.example           ← шаблон переменных окружения
├── railway.toml           ← конфиг для Railway
├── supabase_schema.sql    ← SQL-схема базы данных
└── public/
    └── lastDLC-v2.html    ← фронтенд (положи сюда)
```

---

## Шаг 1 — Supabase (база данных)

1. Зайди на **https://supabase.com** → Sign up (бесплатно)
2. **New project** → придумай название и пароль (сохрани пароль!)
3. Подожди ~2 минуты пока проект создаётся
4. Слева → **SQL Editor** → **New query**
5. Скопируй весь код из `supabase_schema.sql` → вставь → **Run**
6. Слева → **Settings** → **API**:
   - Скопируй **Project URL** → это `SUPABASE_URL`
   - Скопируй **service_role** (секретный!) → это `SUPABASE_SERVICE_KEY`

---

## Шаг 2 — Resend (отправка email)

1. Зайди на **https://resend.com** → Sign up (бесплатно, 100 писем/день)
2. **API Keys** → **Create API Key** → скопируй → это `RESEND_API_KEY`
3. Для теста можно использовать `FROM_EMAIL=onboarding@resend.dev`
4. Для продакшна: **Domains** → добавь свой домен и верифицируй DNS

---

## Шаг 3 — reCAPTCHA v3

1. Зайди на **https://www.google.com/recaptcha/admin**
2. **+** → Добавить сайт:
   - Тип: **reCAPTCHA v3**
   - Домены: добавь `localhost` и свой домен (например `lastdlc.com`)
3. Получишь два ключа:
   - **Site Key** (публичный) → вставь в `lastDLC-v2.html` вместо `YOUR_RECAPTCHA_SITE_KEY` (в двух местах!)
   - **Secret Key** (секретный) → это `RECAPTCHA_SECRET`

---

## Шаг 4 — Railway (деплой бэкенда)

1. Зайди на **https://railway.app** → Sign up через GitHub (бесплатно)
2. **New Project** → **Deploy from GitHub repo**
3. Загрузи папку `lastdlc-backend` в GitHub репозиторий
4. Railway сам найдёт `railway.toml` и задеплоит

### Переменные окружения в Railway:
Слева → твой сервис → **Variables** → добавь:

```
SUPABASE_URL        = https://ТВОЙ_ПРОЕКТ.supabase.co
SUPABASE_SERVICE_KEY = eyJ...
RESEND_API_KEY      = re_...
RECAPTCHA_SECRET    = 6Lc...
FROM_EMAIL          = noreply@lastdlc.com
```

5. После деплоя Railway даст URL вида `https://lastdlc-backend-production.up.railway.app`
6. Скопируй этот URL → вставь в `lastDLC-v2.html` в строку:
   ```js
   const API = 'https://lastdlc-backend-production.up.railway.app';
   ```

---

## Шаг 5 — Фронтенд

### Вариант A: Railway (всё в одном)
1. Положи `lastDLC-v2.html` в папку `public/` внутри `lastdlc-backend/`
2. Бэкенд сам отдаёт файлы из `public/` — перейди на `https://твой-railway-url/lastDLC-v2.html`

### Вариант B: Netlify (отдельно)
1. Зайди на **https://app.netlify.com/drop**
2. Перетащи `lastDLC-v2.html` → готово, получишь URL

---

## Шаг 6 — Локальный запуск (для теста)

```bash
# Установи Node.js если нет: https://nodejs.org

cd lastdlc-backend
cp .env.example .env
# Заполни .env своими ключами

npm install
npm run dev
```

Открой `lastDLC-v2.html` в браузере (или `http://localhost:3000`)

---

## ⚠️ Важно для продакшна (потом)

- [ ] Хэшировать пароли через **bcrypt** (сейчас хранятся в открытом виде — только для старта!)
- [ ] Заменить session-токены на **JWT**
- [ ] Добавить загрузку аватара через **Supabase Storage**
- [ ] Верифицировать домен в Resend для нормального FROM_EMAIL
- [ ] Добавить HTTPS (Railway даёт автоматически)

---

## Структура API

| Метод | URL | Описание |
|-------|-----|----------|
| POST | `/api/register` | Шаг 1 регистрации, отправляет код на email |
| POST | `/api/verify-email` | Шаг 2 регистрации, проверяет код |
| POST | `/api/login` | Шаг 1 входа, отправляет код на email |
| POST | `/api/verify-login` | Шаг 2 входа, проверяет код → даёт токен |
| GET  | `/api/me` | Проверить текущую сессию |
| POST | `/api/logout` | Выход |

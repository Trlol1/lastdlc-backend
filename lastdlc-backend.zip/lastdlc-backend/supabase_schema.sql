-- =============================================================
-- lastDLC — SQL схема для Supabase
-- Запусти это в Supabase → SQL Editor → New query
-- =============================================================

-- Пользователи
create table if not exists users (
  id           uuid primary key default gen_random_uuid(),
  username     text unique not null,
  email        text unique not null,
  password_hash text not null,
  avatar_url   text,
  created_at   timestamptz default now()
);

-- Ожидающие подтверждения (регистрация)
create table if not exists pending_verifications (
  email         text primary key,
  username      text not null,
  password_hash text not null,
  code          text not null,
  expires_at    timestamptz not null,
  created_at    timestamptz default now()
);

-- Коды для входа (2FA по email)
create table if not exists login_codes (
  user_id    uuid primary key references users(id) on delete cascade,
  code       text not null,
  expires_at timestamptz not null,
  created_at timestamptz default now()
);

-- Сессии
create table if not exists sessions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references users(id) on delete cascade,
  token      text unique not null,
  created_at timestamptz default now()
);

-- Индексы для скорости
create index if not exists idx_sessions_token on sessions(token);
create index if not exists idx_sessions_user  on sessions(user_id);

-- Автоудаление просроченных кодов (через pg_cron, опционально)
-- Или можно чистить вручную раз в день запросом:
-- delete from pending_verifications where expires_at < now();
-- delete from login_codes where expires_at < now();

-- Row Level Security — отключаем для service_role (бэкенд использует service key)
alter table users                  enable row level security;
alter table pending_verifications  enable row level security;
alter table login_codes            enable row level security;
alter table sessions               enable row level security;

-- Политика: только service_role имеет доступ (анонимы не могут ничего)
-- Это нормально, т.к. фронт идёт через наш Node.js бэкенд, не напрямую в Supabase
create policy "service only" on users                 for all using (false);
create policy "service only" on pending_verifications for all using (false);
create policy "service only" on login_codes           for all using (false);
create policy "service only" on sessions              for all using (false);
